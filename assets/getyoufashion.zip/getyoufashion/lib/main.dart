import 'package:flutter/material.dart';
import 'package:get_your_fashion/provider/auth_provider.dart';
import 'package:get_your_fashion/utils/routes/routes.dart';
import 'package:get_your_fashion/utils/routes/routes_name.dart';
import 'package:provider/provider.dart';

import 'provider/user_token_provider.dart';
void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {

  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {

    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthProvider()),
        ChangeNotifierProvider(create: (context) => UserTokenProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        initialRoute: RoutesName.splash,
        routes: routes,
        theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.white),
    dividerColor: Colors.transparent,
    useMaterial3: true,
      ),
    ));
  }
}

