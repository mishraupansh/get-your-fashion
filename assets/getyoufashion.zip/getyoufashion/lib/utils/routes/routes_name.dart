class RoutesName {

  static const String splash ='/';
  static const String loginScreen ='/login_screen';
  static const String otpScreen ='/otp_screen';
  static const String bottomScreen ='/bottom_nev_bar';
  static const String categoryScreen ='/category_screen';

}