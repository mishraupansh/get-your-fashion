class AppUrl{
  static const String baseUrl = 'https://butick.wishufashion.com/api/Mobile_app/';
  static const String loginUrl = '${baseUrl}login_number';
  static const String registerUrl = '${baseUrl}register';
  static const String homeSlider = '${baseUrl}slider';
  static const String categoryUrl ='${baseUrl}categori';
  static const String subCategoryUrl ='${baseUrl}sub_categori?';
}